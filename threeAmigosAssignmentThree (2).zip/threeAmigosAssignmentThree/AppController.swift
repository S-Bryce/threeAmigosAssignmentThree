//
//  AppController.swift
//  threeAmigosAssignmentThree
//
//  Created by Bryce Shurts on 10/11/23.
//

import UIKit

class AppController: UIViewController {
    
    
}
